//
//  ViewController.swift
//  Bournemouth WW2
//
//  Created by Leonardo Grieco (s5110005) on 04/12/2019.
//  Copyright © 2019 Leonardo Grieco (s5110005). All rights reserved.
//

import Foundation
import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var ExploreButton: ExploreButton!
    performSegue(withIdentfier: "ExploreButton", sender: self)
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
