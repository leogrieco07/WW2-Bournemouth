//
//  SecondViewController.swift
//  Bournemouth WW2
//
//  Created by Leonardo Grieco (s5110005) on 04/12/2019.
//  Copyright © 2019 Leonardo Grieco (s5110005). All rights reserved.
//

import Foundation
import UIKit
import MapKit

class SecondViewController: UIViewController, NSObject, MKAnnotation {
    
    var coordinate: CLLocationCoordinate2D
    var title: String?
    
    init(coordinate: CLLocationCoordinate2D, title:String) {
        self.coordinate = coordinate
        self.title= title 
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let BealesCoordinate = CLLocationCoordinate2D(latitude: 50.72 longitiude: -1.52)
        let BealesAnnotation = CustomAnnotation(coordinate: BealesCoordinate, title: "Beales Deparment Store)
            mapView.addAnnotation(BealesAnnotation)
    }
}
